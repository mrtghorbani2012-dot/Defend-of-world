extends CharacterBody2D

@export var speed: float = 150.0

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

var last_direction: String = "down"

func _ready() -> void:
    _create_animations()
    anim.play("walk_down")

func _physics_process(_delta: float) -> void:
    var input_vector := Input.get_vector(
        "ui_left",
        "ui_right",
        "ui_up",
        "ui_down"
    )

    if input_vector != Vector2.ZERO:
        velocity = input_vector * speed

        if abs(input_vector.x) > abs(input_vector.y):
            last_direction = "right" if input_vector.x > 0.0 else "left"
        else:
            last_direction = "down" if input_vector.y > 0.0 else "up"

        var animation_name := "walk_" + last_direction
        if anim.animation != animation_name or not anim.is_playing():
            anim.play(animation_name)
    else:
        velocity = Vector2.ZERO
        anim.stop()
        anim.animation = "walk_" + last_direction
        anim.frame = 0

    move_and_slide()


func _create_animations() -> void:
    var texture: Texture2D = load("res://Assets/player_sheet.png")
    var frames := SpriteFrames.new()
    var directions := ["down", "left", "right", "up"]

    for row in range(4):
        var animation_name := "walk_" + directions[row]
        frames.add_animation(animation_name)
        frames.set_animation_speed(animation_name, 8.0)
        frames.set_animation_loop(animation_name, true)

        for column in range(4):
            var atlas := AtlasTexture.new()
            atlas.atlas = texture
            atlas.region = Rect2(column * 16, row * 16, 16, 16)
            frames.add_frame(animation_name, atlas)

    anim.sprite_frames = frames
