# Godot 4.3 - Four Direction Player Demo

## Run
1. Extract this ZIP.
2. Open Godot 4.3.
3. Choose Import and select `project.godot` inside this folder.
4. Open the project and press F6 or F5 (F5 runs the main scene).

## Controls
- Arrow keys: move in four directions.
- When stopped, the first frame of the last direction is shown.

## Replace the placeholder character
The included `Assets/player_sheet.png` is only a sample 4x4 sheet:
- 4 columns (frames)
- 4 rows in this order: down, left, right, up
- Each frame is 16x16 pixels

To use your own sheet, replace `player_sheet.png` while keeping the same 4x4 layout and frame size,
or edit the row/column/frame-size values in `Scripts/Player.gd`.

This is a starter project, not a complete game. It is designed for Godot 4.3.
